#!/usr/bin/env -S uv run --quiet --script
# /// script
# requires-python = ">=3.13,<3.14"
# dependencies = [
#     "playwright==1.61.0",
# ]
# ///
# Version authority: https://pypi.org/project/playwright/
"""Run the representative browser accessibility acceptance for docs and web client."""

from __future__ import annotations

import argparse
import contextlib
import functools
import http.server
import json
import pathlib
import re
import subprocess
import sys
import threading
from collections.abc import Iterator, Sequence
from typing import Any
from urllib.parse import quote, urlparse

from playwright.sync_api import BrowserContext, Page, Route, sync_playwright  # ty: ignore[unresolved-import]
from playwright.sync_api import Error as PlaywrightError  # ty: ignore[unresolved-import]

ROOT = pathlib.Path(__file__).resolve().parent.parent
SITE = ROOT / "site"
CLIENT = ROOT / "clients/web"
DOCUMENT_SURFACES = (
    ("index.html", "homepage"),
    ("2. Agents/2.1. First Agent.html", "first Python exercise"),
    ("2. Agents/2.6. Workshop.html", "cumulative workshop"),
    ("4. Quality/4.8. Developer Handoff.html", "developer to platform handoff"),
    ("0. Overview/0.3. Ecosystem.html", "dense diagram page"),
    ("3. Capabilities/3.6. A2A.html", "A2A page"),
    ("4. Quality/4.6. Security.html", "security page"),
    ("8. Community/8.7. Capstone.html", "capstone page"),
    ("404.html", "404 recovery page"),
)
CONTRAST_COLORS = """
selector => {
  const element = document.querySelector(selector);
  if (!element) throw new Error(`missing contrast target: ${selector}`);
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 1;
  const context = canvas.getContext("2d", { willReadFrequently: true });
  const rgba = value => {
    context.clearRect(0, 0, 1, 1);
    context.fillStyle = value;
    context.fillRect(0, 0, 1, 1);
    return [...context.getImageData(0, 0, 1, 1).data];
  };
  const over = (top, bottom) => {
    const alpha = top[3] / 255;
    return [
      top[0] * alpha + bottom[0] * (1 - alpha),
      top[1] * alpha + bottom[1] * (1 - alpha),
      top[2] * alpha + bottom[2] * (1 - alpha),
      255,
    ];
  };
  const backgrounds = [];
  for (let node = element; node; node = node.parentElement) {
    backgrounds.push(rgba(getComputedStyle(node).backgroundColor));
  }
  const background = backgrounds.reverse().reduce((color, layer) => over(layer, color), [255, 255, 255, 255]);
  const foreground = over(rgba(getComputedStyle(element).color), background);
  return { foreground: foreground.slice(0, 3), background: background.slice(0, 3) };
}
"""


class AcceptanceError(RuntimeError):
    """A browser-observed accessibility contract failed."""


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    """Serve fixtures without polluting acceptance output with request logs."""

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        """Suppress one local request log line."""


@contextlib.contextmanager
def serve(directory: pathlib.Path) -> Iterator[str]:
    """Serve one static directory on an ephemeral loopback port."""
    handler = functools.partial(QuietHandler, directory=str(directory))
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_port}"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def require(condition: bool, message: str) -> None:
    """Raise a concise acceptance failure."""
    if not condition:
        raise AcceptanceError(message)


def open_page(page: Page, url: str) -> None:
    """Open a local surface and require a successful main response."""
    response = page.goto(url, wait_until="load")
    require(response is not None and response.ok, f"{url}: expected a successful document response")


def keyboard_smoke(page: Page, url: str, skip_selector: str, next_selector: str) -> None:
    """Prove the skip route and next control are reachable and visibly focused."""
    open_page(page, url)
    skip = page.locator(skip_selector)
    before = skip.bounding_box()
    before_opacity = skip.evaluate("element => Number(getComputedStyle(element).opacity)")
    page.keyboard.press("Tab")
    page.wait_for_function(
        """selector => {
          const element = document.querySelector(selector);
          const box = element.getBoundingClientRect();
          return element === document.activeElement && Number(getComputedStyle(element).opacity) > 0.9
            && box.right > 0 && box.bottom > 0 && box.left < innerWidth && box.top < innerHeight;
        }""",
        arg=skip_selector,
    )
    after = skip.bounding_box()
    require(
        skip.evaluate("element => element === document.activeElement"), f"{url}: first Tab must focus the skip link"
    )
    require(
        after is not None
        and 0 <= after["x"] < page.viewport_size["width"]
        and 0 <= after["y"] < page.viewport_size["height"]
        and (before is None or before["x"] < 0 or before_opacity < 0.1),
        f"{url}: focused skip link must move visibly into the viewport",
    )
    target = skip.get_attribute("href")
    require(bool(target and target.startswith("#")), f"{url}: skip link needs a same-page target")
    page.keyboard.press("Enter")
    page.wait_for_function("target => location.hash === target", arg=target)
    require(page.locator(target).count() == 1, f"{url}: skip target {target!r} must exist")

    open_page(page, url)
    page.keyboard.press("Tab")
    page.keyboard.press("Tab")
    next_control = page.locator(next_selector)
    require(
        next_control.evaluate("element => element === document.activeElement"),
        f"{url}: second Tab must reach {next_selector!r}",
    )
    require(page.evaluate("document.activeElement.matches(':focus-visible')"), f"{url}: keyboard focus must be visible")


def accessibility_tree_smoke(context: BrowserContext, page: Page, url: str, label: str) -> None:
    """Inspect one Chromium accessibility tree for landmarks and named controls."""
    open_page(page, url)
    heading = page.locator("h1").inner_text().strip()
    session = context.new_cdp_session(page)
    try:
        tree = session.send("Accessibility.getFullAXTree")
    finally:
        session.detach()
    nodes = [node for node in tree["nodes"] if not node.get("ignored")]
    roles = [node.get("role", {}).get("value") for node in nodes]
    require(roles.count("main") == 1, f"{label}: accessibility tree needs exactly one main landmark")
    require(
        any(
            node.get("role", {}).get("value") == "heading" and node.get("name", {}).get("value", "").strip() == heading
            for node in nodes
        ),
        f"{label}: accessibility tree does not expose the H1 {heading!r}",
    )
    interactive_roles = {"button", "checkbox", "combobox", "radio", "searchbox", "textbox"}
    unnamed = [
        node.get("role", {}).get("value")
        for node in nodes
        if node.get("role", {}).get("value") in interactive_roles and not node.get("name", {}).get("value", "").strip()
    ]
    require(not unnamed, f"{label}: accessibility tree has unnamed interactive controls: {unnamed}")


def search_smoke(page: Page, url: str) -> None:
    """Exercise the hydrated Zensical search semantics and recovery results."""
    open_page(page, url)
    search_button = page.get_by_role("button", name=re.compile(r"^Search"))
    require(search_button.count() >= 1, f"{url}: search trigger is missing")
    search_button.first.click()
    search_input = page.get_by_role("combobox", name="Search")
    search_input.wait_for(state="visible")
    require(search_input.get_attribute("aria-autocomplete") == "list", f"{url}: search must autocomplete a list")
    controls = search_input.get_attribute("aria-controls")
    require(bool(controls), f"{url}: search must identify its result list")
    require(
        search_input.evaluate("(element, id) => Boolean(element.getRootNode().getElementById(id))", controls),
        f"{url}: search result list {controls!r} is missing",
    )
    button_labels = search_input.evaluate(
        "element => [...element.getRootNode().querySelectorAll('button')]"
        ".map(button => button.getAttribute('aria-label'))"
    )
    require(
        button_labels == ["Close search", "Filter search results"],
        f"{url}: search buttons need stable accessible names, got {button_labels}",
    )
    search_input.fill("A2A")
    handle = search_input.element_handle()
    require(handle is not None, f"{url}: search input disappeared")
    page.wait_for_function("element => element.getAttribute('aria-expanded') === 'true'", arg=handle)
    require(
        search_input.evaluate("element => element.getRootNode().querySelectorAll('ol a').length") > 0,
        f"{url}: search did not return a recovery route for A2A",
    )


def content_controls_smoke(page: Page, url: str) -> None:
    """Exercise a dense diagram inventory, table semantics, and a keyboard copy control."""
    open_page(page, url)
    diagrams = page.locator("article pre > code").evaluate_all(
        "nodes => nodes.filter(node => /^(flowchart|sequenceDiagram|graph)\\b/.test(node.textContent.trim())).length"
    )
    require(diagrams >= 3, f"{url}: representative page no longer exercises a dense diagram surface")
    require(page.get_by_role("columnheader").count() > 0, f"{url}: representative table has no column headers")
    copy_button = page.get_by_role("button", name="Copy to clipboard").first
    copy_button.focus()
    require(
        copy_button.evaluate("element => element === document.activeElement && element.matches(':focus-visible')"),
        f"{url}: code-copy control is not keyboard focused",
    )
    page.keyboard.press("Enter")


def client_rpc(route: Route) -> None:
    """Return deterministic A2A task snapshots for browser-only client interaction checks."""
    request = json.loads(route.request.post_data or "{}")
    method = request.get("method")
    if method == "tasks/cancel":
        require(request.get("params") == {"id": "task-cancel"}, "web client sent the wrong cancellation target")
        state, task_id = "canceled", "task-cancel"
    elif method == "message/send":
        parts = request.get("params", {}).get("message", {}).get("parts", [])
        require(
            parts
            and parts[0].get("data", {}).get("response", {}).get("confirmed") is False
            and parts[0].get("metadata", {}).get("adk_type") == "function_response",
            "web client sent the wrong denial response",
        )
        state, task_id = "completed", "task-approval"
    else:
        raise AcceptanceError(f"web client sent unexpected RPC method {method!r}")
    body = {
        "jsonrpc": "2.0",
        "id": request.get("id"),
        "result": {
            "kind": "task",
            "id": task_id,
            "contextId": "browser-acceptance",
            "status": {"state": state},
            "artifacts": [],
        },
    }
    route.fulfill(status=200, content_type="application/json", body=json.dumps(body))


def web_client_interaction_smoke(page: Page, url: str) -> None:
    """Exercise live status, cancellation, and approval controls without an agent."""
    open_page(page, url)
    require(page.locator("#log[aria-live='polite']").count() == 1, f"{url}: task log must announce updates")
    page.route(urlparse(url)._replace(path="/").geturl(), client_rpc)
    page.evaluate(
        """() => {
          state.baseUrl = location.origin;
          handleResult({
            kind: "status-update",
            contextId: "browser-acceptance",
            taskId: "task-cancel",
            status: { state: "working", message: { parts: [{ kind: "text", text: "Working" }] } },
          });
        }"""
    )
    cancel = page.get_by_role("button", name="Cancel the active task")
    require(cancel.is_enabled(), f"{url}: active task must enable cancellation")
    cancel.click()
    page.wait_for_selector(".state-canceled")
    require(cancel.is_disabled(), f"{url}: canceled task must disable cancellation")

    page.evaluate(
        """() => handleResult({
          kind: "status-update",
          contextId: "browser-acceptance",
          taskId: "task-approval",
          status: {
            state: "input-required",
            message: { parts: [{
              kind: "data",
              data: {
                id: "approval-call",
                name: "adk_request_confirmation",
                args: {
                  originalFunctionCall: { name: "restart_service", args: { service: "api" } },
                  toolConfirmation: { hint: "Review the restart evidence." },
                },
              },
              metadata: { adk_type: "function_call" },
            }] },
          },
        })"""
    )
    rationale = page.get_by_label("Approval rationale")
    require(
        rationale.evaluate("element => element === document.activeElement && element.required"),
        f"{url}: approval rationale must be required and receive focus",
    )
    require(page.get_by_role("button", name="Approve").count() == 1, f"{url}: approval action is missing")
    deny = page.get_by_role("button", name="Deny")
    require(deny.count() == 1, f"{url}: denial action is missing")
    deny.click()
    page.wait_for_selector(".state-completed")


def web_client_transport_smoke(page: Page, url: str) -> None:
    """Prevent duplicate turns and cross-endpoint reuse of conversation authority."""
    open_page(page, url)
    results = page.evaluate(
        """async () => {
          const originalFetch = window.fetch;
          const completed = { result: { kind: "message", parts: [{ kind: "text", text: "Done" }] } };
          const outcomes = [];
          try {
            for (const [status, body, expectedCalls, expectedError] of [
              [200, completed, 1, false],
              [500, {}, 1, true],
              [200, { error: { code: -32603, message: "Internal error" } }, 1, true],
              [200, { error: { code: -32601, message: "Method not found" } }, 2, false],
            ]) {
              const methods = [];
              window.fetch = async (_, options) => {
                methods.push(JSON.parse(options.body).method);
                return new Response(JSON.stringify(methods.length === 1 ? body : completed), {
                  status: methods.length === 1 ? status : 200,
                  headers: { "content-type": "application/json" },
                });
              };
              let failed = false;
              try { await streamMessage({ kind: "message", parts: [] }); }
              catch { failed = true; }
              outcomes.push(methods.length === expectedCalls && failed === expectedError &&
                methods[0] === "message/stream" && (expectedCalls === 1 || methods[1] === "message/send"));
            }
          } finally { window.fetch = originalFetch; }
          return outcomes;
        }"""
    )
    require(results == [True] * 4, f"{url}: streaming fallback replayed a turn or hid an error")

    page.evaluate(
        """() => {
          state.baseUrl = location.origin;
          state.contextId = "old-context";
          state.taskId = "old-approval";
          state.activeTaskId = "old-approval";
          $("card").textContent = "Existing agent card";
          renderConfirmation({ id: "old-call", name: "adk_request_confirmation", args: {
            originalFunctionCall: { name: "restart_service", args: { name: "inventory" } },
          } }, "old-approval");
          window.fetch = async url => new Response(JSON.stringify({
            name: "Test agent", version: "1", description: "Synthetic card",
            skills: url.includes("/malformed/") ? {} : [],
          }), { status: url.includes("/unavailable/") ? 503 : 200 });
        }"""
    )
    base = urlparse(url)._replace(path="").geturl()
    for endpoint in ("unavailable", "malformed"):
        page.get_by_label("A2A base URL").fill(f"{base}/{endpoint}")
        page.get_by_role("button", name="Connect", exact=True).click()
        page.wait_for_function("!state.discovering")
        require(
            page.evaluate(
                """state.baseUrl === location.origin && state.taskId === 'old-approval' &&
                $("card").textContent === 'Existing agent card' && $("log").querySelector('.confirm') !== null"""
            ),
            f"{url}: failed or malformed discovery changed the active conversation",
        )

    page.evaluate(
        """() => {
          window.discoveryFetch = window.fetch;
          window.pendingRequests = [];
          window.fetch = (url, options) => {
            window.pendingRequests.push(options ? JSON.parse(options.body).method : "discovery");
            return new Promise(resolve => { window.resolveDiscovery = resolve; });
          };
        }"""
    )
    page.get_by_label("A2A base URL").fill(f"{base}/new")
    page.get_by_role("button", name="Connect", exact=True).click()
    require(
        page.get_by_role("button", name="Deny", exact=True).is_disabled()
        and page.get_by_role("button", name="Cancel the active task").is_disabled(),
        f"{url}: discovery must disable approval and cancellation controls",
    )
    page.evaluate(
        """() => {
          const approval = $("log").querySelector('.confirm form');
          approval.querySelector('input').value = 'Reviewed';
          approval.dispatchEvent(new Event('submit', { cancelable: true }));
          $("task-cancel").dispatchEvent(new Event('click'));
          $("connect-form").dispatchEvent(new Event('submit', { cancelable: true }));
          sendParts([{ kind: 'text', text: 'Must wait for discovery' }]);
        }"""
    )
    require(
        page.evaluate("JSON.stringify(window.pendingRequests) === '[\"discovery\"]'"),
        f"{url}: discovery overlapped a turn, approval, cancellation, or second discovery",
    )
    page.evaluate("window.resolveDiscovery(new Response('{}', { status: 503 }))")
    page.wait_for_function("!state.discovering")

    page.evaluate(
        """() => {
          state.streaming = true;
          window.pendingRequests = [];
          window.fetch = (_, options) => {
            const method = options ? JSON.parse(options.body).method : 'discovery';
            window.pendingRequests.push(method);
            if (method === 'message/stream') return Promise.resolve(new Response(new ReadableStream({
              start(controller) { window.pendingStream = controller; },
            }), { headers: { 'content-type': 'text/event-stream' } }));
            return new Promise(resolve => { window.resolveCancel = resolve; });
          };
        }"""
    )
    page.get_by_role("button", name="Deny", exact=True).click()
    require(
        page.get_by_role("button", name="Connect", exact=True).is_disabled()
        and page.get_by_role("button", name="Cancel the active task").is_enabled(),
        f"{url}: a pending streamed approval must block discovery while permitting cancellation",
    )
    page.evaluate('$("connect-form").dispatchEvent(new Event("submit", { cancelable: true }))')
    page.get_by_role("button", name="Cancel the active task").click()
    page.evaluate("window.pendingStream.close()")
    page.wait_for_function("!state.sending")
    require(
        page.get_by_role("button", name="Connect", exact=True).is_disabled(),
        f"{url}: discovery resumed before the cancellation response arrived",
    )
    page.evaluate('$("connect-form").dispatchEvent(new Event("submit", { cancelable: true }))')
    require(
        page.evaluate('JSON.stringify(window.pendingRequests) === \'["message/stream","tasks/cancel"]\''),
        f"{url}: pending approval or cancellation overlapped endpoint discovery",
    )
    page.evaluate(
        """window.resolveCancel(new Response(JSON.stringify({ result: {
          kind: 'task', id: 'old-approval', status: { state: 'canceled' },
        } })))"""
    )
    page.wait_for_function("!state.canceling")
    require(
        page.get_by_role("button", name="Deny", exact=True).is_disabled(),
        f"{url}: an answered approval was re-enabled after cancellation",
    )
    page.evaluate("() => { window.fetch = window.discoveryFetch; }")
    page.get_by_label("A2A base URL").fill(f"{base}/new")
    page.get_by_role("button", name="Connect", exact=True).click()
    page.wait_for_function("state.baseUrl.endsWith('/new')")
    require(
        page.evaluate("state.contextId === null && state.taskId === null && state.activeTaskId === null"),
        f"{url}: a different endpoint inherited conversation or approval identifiers",
    )


def forced_colors_smoke(page: Page, url: str) -> None:
    """Exercise the web client's forced-colors fallback in an emulated browser context."""
    open_page(page, url)
    require(page.evaluate("matchMedia('(forced-colors: active)').matches"), f"{url}: forced colors is not active")
    border = page.evaluate(
        """() => {
          const badge = document.createElement("span");
          badge.className = "state state-working";
          badge.textContent = "working";
          document.body.append(badge);
          const style = getComputedStyle(badge);
          return { style: style.borderStyle, width: style.borderTopWidth };
        }"""
    )
    require(border == {"style": "solid", "width": "2px"}, f"{url}: forced-colors border fallback is missing")


def reflow_smoke(page: Page, url: str) -> None:
    """Reject document-level horizontal overflow at the WCAG reflow width."""
    page.set_viewport_size({"width": 320, "height": 800})
    open_page(page, url)
    widths = page.evaluate(
        """() => ({
          viewport: document.documentElement.clientWidth,
          content: Math.max(document.documentElement.scrollWidth, document.body.scrollWidth),
        })"""
    )
    require(
        widths["content"] <= widths["viewport"] + 1,
        f"{url}: 320px viewport overflows horizontally ({widths['content']}px > {widths['viewport']}px)",
    )


def duration_seconds(value: str) -> float:
    """Return the longest duration in a computed CSS duration list."""
    durations = []
    for item in value.split(","):
        item = item.strip()
        durations.append(float(item[:-2]) / 1000 if item.endswith("ms") else float(item[:-1]))
    return max(durations, default=0)


def reduced_motion_smoke(page: Page, url: str, *, stops_animation: bool) -> None:
    """Exercise each surface's reduced-motion media rule against a two-second probe."""
    open_page(page, url)
    values = page.evaluate(
        """() => {
          const probe = document.createElement("div");
          probe.style.cssText = "transition-duration: 2s; animation-duration: 2s";
          document.body.append(probe);
          const style = getComputedStyle(probe);
          return { transition: style.transitionDuration, animation: style.animationDuration };
        }"""
    )
    require(
        page.evaluate("matchMedia('(prefers-reduced-motion: reduce)').matches"), f"{url}: reduced motion is not active"
    )
    require(duration_seconds(values["transition"]) <= 0.001, f"{url}: reduced motion did not stop transitions")
    if stops_animation:
        require(duration_seconds(values["animation"]) <= 0.001, f"{url}: reduced motion did not stop animations")


def luminance(rgb: Sequence[float]) -> float:
    """Return WCAG relative luminance for one sRGB triplet."""
    channels = [value / 255 for value in rgb]
    linear = [value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4 for value in channels]
    return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]


def contrast_ratio(foreground: Sequence[float], background: Sequence[float]) -> float:
    """Return the WCAG contrast ratio between two opaque sRGB triplets."""
    lighter, darker = sorted((luminance(foreground), luminance(background)), reverse=True)
    return (lighter + 0.05) / (darker + 0.05)


def contrast_smoke(page: Page, selector: str, label: str) -> None:
    """Require AA normal-text contrast for one computed browser surface."""
    colors = page.evaluate(CONTRAST_COLORS, selector)
    ratio = contrast_ratio(colors["foreground"], colors["background"])
    require(ratio >= 4.5, f"{label}: computed contrast is {ratio:.2f}:1, expected at least 4.5:1")


def block_external_requests(context: BrowserContext) -> None:
    """Keep the acceptance deterministic and independent of optional web fonts."""
    context.route(
        "**/*",
        lambda route: (
            route.continue_() if urlparse(route.request.url).hostname in {"127.0.0.1", "localhost"} else route.abort()
        ),
    )


def run_acceptance() -> None:
    """Exercise landing/course templates and the dependency-free client."""
    require(SITE.joinpath("index.html").is_file(), "site/index.html is missing; run `mise run build:docs`")
    require(CLIENT.joinpath("index.html").is_file(), "clients/web/index.html is missing")
    with serve(SITE) as docs, serve(CLIENT) as client, sync_playwright() as playwright:
        try:
            browser = playwright.chromium.launch(headless=True)
        except PlaywrightError as error:
            raise AcceptanceError("Chromium is unavailable; run `mise run install:accessibility`") from error
        with browser:
            context = browser.new_context(viewport={"width": 1280, "height": 900}, color_scheme="light")
            block_external_requests(context)
            page = context.new_page()
            homepage = f"{docs}/index.html"
            keyboard_smoke(page, homepage, ".md-skip", ".md-header__button.md-logo")
            search_smoke(page, homepage)
            for path, label in DOCUMENT_SURFACES:
                accessibility_tree_smoke(context, page, f"{docs}/{quote(path)}", label)
            dense_page = f"{docs}/{quote('0. Overview/0.3. Ecosystem.html')}"
            content_controls_smoke(page, dense_page)
            reflow_smoke(page, homepage)
            reflow_smoke(page, f"{docs}/{quote('4. Quality/4.6. Security.html')}")
            open_page(page, homepage)
            contrast_smoke(page, ".md-content__inner > p", "documentation body text")
            contrast_smoke(page, ".md-content__inner p a", "documentation content link")

            web_client = f"{client}/index.html"
            keyboard_smoke(page, web_client, ".skip-link", "#base-url")
            accessibility_tree_smoke(context, page, web_client, "web client")
            web_client_interaction_smoke(page, web_client)
            web_client_transport_smoke(page, web_client)
            reflow_smoke(page, web_client)
            open_page(page, web_client)
            contrast_smoke(page, "header h1", "web client heading")
            page.evaluate(
                """() => ["working", "input-required", "completed"].forEach(state => {
                  const badge = document.createElement("span");
                  badge.id = `contrast-${state}`;
                  badge.className = `state state-${state}`;
                  badge.textContent = state;
                  document.body.append(badge);
                })"""
            )
            for state in ("working", "input-required", "completed"):
                contrast_smoke(page, f"#contrast-{state}", f"web client {state} state")
            context.close()

            reduced = browser.new_context(reduced_motion="reduce", color_scheme="light")
            block_external_requests(reduced)
            reduced_page = reduced.new_page()
            reduced_motion_smoke(reduced_page, f"{docs}/index.html", stops_animation=False)
            reduced_motion_smoke(reduced_page, f"{client}/index.html", stops_animation=True)
            reduced.close()

            forced = browser.new_context(forced_colors="active", color_scheme="light")
            block_external_requests(forced)
            forced_page = forced.new_page()
            forced_colors_smoke(forced_page, web_client)
            forced.close()

    require(abs(contrast_ratio((0, 0, 0), (255, 255, 255)) - 21) < 0.001, "contrast calculation self-test failed")
    sys.stdout.write("browser accessibility: documentation and web client passed\n")


def main(argv: Sequence[str] | None = None) -> int:
    """Install the pinned browser or run its acceptance contract."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--install-browser", action="store_true", help="install the Chromium build pinned by Playwright"
    )
    parser.add_argument("--with-deps", action="store_true", help="also install Linux browser system dependencies")
    arguments = parser.parse_args(argv)
    if arguments.install_browser:
        command = [sys.executable, "-m", "playwright", "install"]
        if arguments.with_deps:
            command.append("--with-deps")
        command.append("chromium")
        # Every argv value is a constant selected by the two boolean CLI flags above.
        subprocess.run(command, check=True)  # noqa: S603
        return 0
    if arguments.with_deps:
        parser.error("--with-deps requires --install-browser")
    run_acceptance()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AcceptanceError as error:
        sys.stderr.write(f"browser accessibility: {error}\n")
        raise SystemExit(1) from error
