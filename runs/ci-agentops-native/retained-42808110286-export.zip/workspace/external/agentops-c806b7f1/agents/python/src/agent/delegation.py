"""Multi-agent delegation — a coordinator with least-privilege specialists (Chapter 3.7).

Sub-agents are how one agent hands work to another: the coordinator triages, then
*delegates* by transferring control (ADK routes to the named sub-agent, which shares
the session). The security lesson is **per-agent least privilege**: the diagnosis
specialist holds only read tools (a prompt injection in a log line cannot make it
mutate state — it has no write tool to call), and the remediation specialist holds
only the guarded write actions (it cannot read raw logs, and every action still
pauses for human confirmation). The same wiring underpins A2A — expose a specialist
over A2A (``adk api_server``) and the coordinator can call it across the network as
a ``RemoteA2aAgent`` instead of an in-process sub-agent.
"""

from __future__ import annotations

from google.adk import Agent

from .actions import ACTION_TOOLS
from .memory import KNOWLEDGE_TOOLS
from .model import build_generation_config, build_model
from .telemetry import setup_telemetry
from .tools import ALL_TOOLS

setup_telemetry()

# The diagnosis specialist: read-only by construction.
diagnosis_agent = Agent(
    model=build_model(),
    generate_content_config=build_generation_config(),
    name="diagnosis_agent",
    description="Specialist that diagnoses a specific incident using its runbook and service status.",
    instruction=(
        "You are a diagnosis specialist. Given an incident id, use get_incident for its details and "
        "runbook, get_runbook for the runbook body, and get_service_status for the service. Explain "
        "the likely root cause in a few sentences and cite the runbook. When the coordinator asks "
        "for post-action verification, re-read the incident and service, compare those observations "
        "with the expected recovery evidence, and label recovery unverified when they do not prove "
        "it. You cannot take actions — hand your findings back to the coordinator."
    ),
    tools=[*ALL_TOOLS, *KNOWLEDGE_TOOLS],
)

# The remediation specialist: write-only by construction. It executes a diagnosed,
# runbook-backed plan through the guarded actions (each still pauses for human
# approval with a rationale) but holds no log or runbook readers.
remediation_agent = Agent(
    model=build_model(),
    generate_content_config=build_generation_config(),
    name="remediation_agent",
    description="Specialist that executes approved remediation through the guarded actions.",
    instruction=(
        "You are a remediation specialist. The coordinator hands you a diagnosed incident and a "
        "runbook-backed plan. Call the exact guarded action (restart_service or resolve_incident) "
        "so ADK creates its confirmation request; the coordinator handoff is not approval. After "
        "the engineer approves with a rationale, return only the attempted action and audit result; "
        "never claim service recovery from the action response. Never act without a diagnosis; "
        "never invent targets."
    ),
    tools=[*ACTION_TOOLS],
)

# The coordinator: triages, then routes — diagnosis first, remediation only after.
coordinator_agent = Agent(
    model=build_model(),
    generate_content_config=build_generation_config(),
    name="coordinator_agent",
    description="On-call coordinator that triages incidents and delegates diagnosis and remediation.",
    instruction=(
        "You are the on-call coordinator. Triage with list_incidents and get_service_status. When a "
        "specific incident needs a root-cause analysis, delegate to the diagnosis_agent sub-agent. "
        "Once a diagnosis is confirmed and the engineer wants to act, delegate to the "
        "remediation_agent sub-agent with the incident id, runbook-backed plan, and expected recovery "
        "evidence. Treat its response as action and audit evidence only. Then delegate back to "
        "diagnosis_agent to re-read the incident and service and compare them with the expected "
        "recovery evidence. Summarize the audit and verified observations; never claim recovery "
        "from the action response alone."
    ),
    tools=ALL_TOOLS,
    sub_agents=[diagnosis_agent, remediation_agent],
)
