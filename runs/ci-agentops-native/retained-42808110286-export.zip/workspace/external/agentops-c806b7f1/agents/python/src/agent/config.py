"""Typed, fail-fast configuration for local and deployed agent runtimes."""

from __future__ import annotations

from enum import StrEnum
from pathlib import Path

from pydantic import AliasChoices, Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# The committed dataset is immutable input. Runtime SQLite state lives under
# agents/python/.state by default so approving a mock action never dirties git.
_DEFAULT_DATA_DIR = Path(__file__).resolve().parents[3] / "data"
_DEFAULT_STATE_DIR = Path(__file__).resolve().parents[2] / ".state"


class ModelProvider(StrEnum):
    """Supported ADK model adapters."""

    OPENAI_COMPATIBLE = "openai-compatible"
    GEMINI = "gemini"


class AgentEntrypoint(StrEnum):
    """Runnable agent compositions exposed through the shared ADK package."""

    AGENT = "agent"
    WORKFLOW = "workflow"
    COORDINATOR = "coordinator"


class Settings(BaseSettings):
    """Agent settings parsed once from ``AGENT_*`` and provider SDK variables.

    Cross-field dependencies are validated at construction — parse, don't
    validate scattered — so a bad combination fails at startup with a message
    that names the fix instead of surfacing as a stack trace deep in a turn.
    """

    model_config = SettingsConfigDict(
        env_prefix="AGENT_",
        extra="ignore",
        # Provider SDK aliases stay constructible by field name in tests.
        populate_by_name=True,
        # Allow AGENT_MODEL_TIMEOUT_S → model_timeout_s despite pydantic's
        # reserved ``model_`` namespace; Settings defines no model_* methods.
        protected_namespaces=(),
    )

    # --8<-- [start:settings-provider-fields]
    entrypoint: AgentEntrypoint = AgentEntrypoint.AGENT
    model_provider: ModelProvider = ModelProvider.GEMINI
    # Keep the learner and gateway model aligned with the qualified platform pair.
    model: str = Field(default="gemini-3.5-flash", min_length=1)

    # ``openai-compatible`` describes the ADK client contract, not the
    # deployment topology. These defaults support the optional Ollama path;
    # Part II instead points the adapter at agentgateway.
    openai_base_url: str | None = Field(
        default="http://127.0.0.1:11434/v1",
        validation_alias=AliasChoices("OPENAI_BASE_URL"),
    )
    openai_api_key: SecretStr | None = Field(
        default=SecretStr("local-ollama"),
        validation_alias=AliasChoices("OPENAI_API_KEY"),
    )

    # Default Gemini path: an AI Studio API key; optional Enterprise/Vertex via ADC
    # with an explicit project and location.
    google_api_key: SecretStr | None = Field(
        default=None,
        validation_alias=AliasChoices("GOOGLE_API_KEY"),
    )
    google_genai_use_enterprise: bool = Field(
        default=False,
        validation_alias=AliasChoices("GOOGLE_GENAI_USE_ENTERPRISE"),
    )
    google_cloud_project: str | None = Field(
        default=None,
        validation_alias=AliasChoices("GOOGLE_CLOUD_PROJECT"),
    )
    google_cloud_location: str | None = Field(
        default=None,
        validation_alias=AliasChoices("GOOGLE_CLOUD_LOCATION"),
    )
    # --8<-- [end:settings-provider-fields]
    deprecated_gateway_enabled: str | None = Field(
        default=None,
        validation_alias=AliasChoices("AGENT_GATEWAY_ENABLED"),
        exclude=True,
        repr=False,
    )

    mcp_url: str | None = None
    # Bearer token sent to a JWT/API-key-secured gateway MCP route (Ch. 5.5).
    # Unset for the default unauthenticated local route.
    mcp_token: SecretStr | None = None

    # Optional host dev/eval prompt-registry pin (Ch. 7.0), e.g.
    # prompts:/agentops-agent-instruction/2. The minimal production image omits
    # MLflow and uses the committed instruction; unset needs no MLflow server.
    prompt_uri: str | None = None

    data_dir: Path = _DEFAULT_DATA_DIR
    state_dir: Path = _DEFAULT_STATE_DIR

    # Bind and advertised A2A addresses are deliberately separate. The host
    # runtime stays loopback-only; Kubernetes explicitly opts into 0.0.0.0.
    # Never advertise 0.0.0.0: it is a listener, not a callable endpoint.
    a2a_bind_host: str = Field(default="127.0.0.1", min_length=1)
    a2a_host: str = Field(default="localhost", min_length=1)
    a2a_port: int = Field(default=8080, ge=1, le=65535)
    a2a_protocol: str = Field(default="http", pattern=r"^https?$")
    a2a_max_llm_calls: int = Field(default=12, ge=1, le=100)
    # Opt-in per-token model streaming for A2A requests (Ch. 3.6). Off by default:
    # chunked output weakens PII redaction (entities spanning chunk boundaries are
    # already sent) and the gateway path reports no usage on streamed responses.
    a2a_streaming: bool = False
    # Graceful-shutdown drain: how long in-flight A2A requests may finish after
    # SIGTERM. Kubernetes' terminationGracePeriodSeconds must exceed this.
    drain_timeout_s: float = Field(default=10.0, gt=0, le=300)

    # Name of the request header carrying a gateway-verified caller identity
    # (Chapter 5.5 / 7.6). ``None`` keeps the unauthenticated synthetic A2A id.
    # Only set this when a trusted gateway validates the JWT and *sets* this
    # header itself, overwriting any client-supplied copy — a raw client could
    # otherwise forge it. When set, the value becomes the audit ``approved_by``.
    trusted_identity_header: str | None = Field(default=None, min_length=1)

    # Resilience: bounded retries with exponential backoff for idempotent reads
    # and model calls; guarded write actions are never retried (Chapter 4.5).
    # Unset preserves each provider's sampling default. Evaluations can opt into
    # lower-variance greedy sampling with AGENT_MODEL_TEMPERATURE=0.
    model_temperature: float | None = Field(default=None, ge=0, le=2)
    model_timeout_s: float = Field(default=60.0, gt=0, le=600)
    tool_timeout_s: float = Field(default=30.0, gt=0, le=600)
    max_retries: int = Field(default=2, ge=0, le=10)
    retry_backoff_s: float = Field(default=0.5, gt=0, le=30)

    # Circuit breaker for idempotent read tools (Chapter 4.5). Off by default so
    # the shipped behavior stays "retry only". When on, a read tool that fails
    # ``circuit_failure_threshold`` times in a row opens: further calls fail fast
    # (shedding load off a dead dependency) until ``circuit_reset_timeout_s``
    # elapses and one trial call tests recovery. Never wraps writes.
    circuit_breaker_enabled: bool = False
    circuit_failure_threshold: int = Field(default=5, ge=1, le=100)
    circuit_reset_timeout_s: float = Field(default=30.0, gt=0, le=600)

    # Optional secondary model tried when the primary fails every retry (Ch. 5.4).
    # ``None`` keeps the single-model path. Uses the same provider/endpoint as the
    # primary — a smaller local model is the intended account-free fallback.
    model_fallback: str | None = Field(default=None, min_length=1)

    # Emergency kill-switch (Chapter 4.5 / 7.7). When true at process startup,
    # every guarded write action refuses before approval. Roll out the setting
    # and restart the process to freeze mutations while reads keep working.
    writes_disabled: bool = False

    # Default-on prompt-injection hardening for tool/retrieval content (Ch. 4.6):
    # spotlight untrusted text and neutralize known injection markers.
    sanitize_tool_output: bool = True

    # Opt-in semantic runbook retrieval (Ch. 3.4). Off by default so the test
    # gate stays deterministic and model-free; requires a local Ollama with the
    # embedding model pulled. Falls back to the keyword scorer on failure.
    semantic_retrieval: bool = False
    embeddings_url: str = Field(default="http://127.0.0.1:11434", min_length=1)
    embedding_model: str = Field(default="nomic-embed-text", min_length=1)
    # A cold local embedding model can take substantially longer to load than
    # an ordinary tool call. Keep that startup bounded without forcing every
    # read tool to inherit the same generous deadline.
    embedding_timeout_s: float = Field(default=120.0, gt=0, le=600)

    # Bounded conversation history / context compaction (Chapter 3.4). ``None``
    # sends ADK's full session history to the model every turn; a positive value
    # keeps only that many most-recent messages and replaces the older ones with
    # one compact synthetic note. Deterministic and model-free, so the offline
    # test gate stays exact. A single user turn can expand into several messages
    # (a model tool call, a tool response, a model answer), so set it with headroom.
    max_history_messages: int | None = Field(default=None, ge=2)

    # Token budgeting and cost attribution (Chapter 7.3). ``None`` disables the
    # budget; zero prices mean unconfigured attribution, never proof of free usage.
    max_tokens_per_session: int | None = Field(default=None, ge=1)
    input_price_per_1k: float = Field(default=0.0, ge=0)
    output_price_per_1k: float = Field(default=0.0, ge=0)

    @model_validator(mode="after")
    def _actionable_cross_field_checks(self) -> Settings:
        """Reject invalid combinations with errors that say what to set and why."""
        # --8<-- [start:settings-provider-validation]
        provider_problems: list[str] = []
        if self.deprecated_gateway_enabled is not None:
            provider_problems.append(
                "AGENT_GATEWAY_ENABLED was removed. Keep AGENT_MODEL_PROVIDER=openai-compatible "
                "and select direct Ollama or agentgateway with OPENAI_BASE_URL "
                "(http://127.0.0.1:11434/v1 or http://127.0.0.1:4000/v1)."
            )
        if self.model_provider is ModelProvider.OPENAI_COMPATIBLE and not self.openai_base_url:
            provider_problems.append(
                "AGENT_MODEL_PROVIDER=openai-compatible requires OPENAI_BASE_URL. Use "
                "http://127.0.0.1:11434/v1 for direct Ollama or http://127.0.0.1:4000/v1 "
                "for the host agentgateway model route."
            )
        if self.model_provider is ModelProvider.OPENAI_COMPATIBLE and (
            not self.openai_api_key or not self.openai_api_key.get_secret_value().strip()
        ):
            provider_problems.append(
                "AGENT_MODEL_PROVIDER=openai-compatible requires OPENAI_API_KEY. Ollama and the open "
                "local gateway accept a non-secret marker such as local-ollama."
            )
        google_api_key = self.google_api_key.get_secret_value().strip() if self.google_api_key else ""
        if self.model_provider is ModelProvider.GEMINI:
            if google_api_key and self.google_genai_use_enterprise:
                provider_problems.append(
                    "AGENT_MODEL_PROVIDER=gemini cannot combine GOOGLE_API_KEY with "
                    "GOOGLE_GENAI_USE_ENTERPRISE=true in this course. Choose AI Studio API-key auth "
                    "or the ADC-backed enterprise path."
                )
            elif self.google_genai_use_enterprise:
                missing_enterprise = [
                    name
                    for name, value in (
                        ("GOOGLE_CLOUD_PROJECT", self.google_cloud_project),
                        ("GOOGLE_CLOUD_LOCATION", self.google_cloud_location),
                    )
                    if not isinstance(value, str) or not value.strip()
                ]
                if missing_enterprise:
                    provider_problems.append(
                        "AGENT_MODEL_PROVIDER=gemini with GOOGLE_GENAI_USE_ENTERPRISE=true requires "
                        + " and ".join(missing_enterprise)
                        + " for the ADC-backed course path."
                    )
        if provider_problems:
            raise ValueError("\n".join(provider_problems))
        # --8<-- [end:settings-provider-validation]
        problems: list[str] = []
        if self.prompt_uri and not self.prompt_uri.startswith("prompts:/"):
            problems.append(
                f"AGENT_PROMPT_URI must look like prompts:/agentops-agent-instruction/2, got {self.prompt_uri!r}. "
                "Unset it to use the committed instruction."
            )
        if self.mcp_url and not self.mcp_url.startswith(("http://", "https://")):
            problems.append(
                f"AGENT_MCP_URL must be an http(s) URL such as http://127.0.0.1:3000/mcp, got {self.mcp_url!r}. "
                "Unset it to call the six read tools directly, in process."
            )
        if self.model_fallback is not None and self.model_fallback == self.model:
            problems.append(
                f"AGENT_MODEL_FALLBACK must differ from AGENT_MODEL (both are {self.model!r}); "
                "a fallback identical to the primary adds no resilience. Unset it or pick a distinct model."
            )
        if problems:
            raise ValueError("\n".join(problems))
        return self

    def require_model_credentials(self) -> None:
        """Require auth at model/config preflight, without blocking offline read tools."""
        if (
            self.model_provider is ModelProvider.GEMINI
            and not self.google_genai_use_enterprise
            and (not self.google_api_key or not self.google_api_key.get_secret_value().strip())
        ):
            raise ValueError(
                "AGENT_MODEL_PROVIDER=gemini requires either GOOGLE_API_KEY for AI Studio, or "
                "GOOGLE_GENAI_USE_ENTERPRISE=true with GOOGLE_CLOUD_PROJECT and GOOGLE_CLOUD_LOCATION for ADC. "
                "Create the repository-root .env from .env.example and run `mise run config:check`. "
                "Offline tests and read tools need no API key."
            )


settings = Settings()
